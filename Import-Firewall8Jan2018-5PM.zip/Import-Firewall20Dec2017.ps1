﻿#Take Provided input from command line like inputfile,rulename,action,profile 
#Bydefault Action is block but can be change just pass the argument allow from command line
#Bydefault Profile is Public but can be change just pass the argument private/domain from command line
#-deleteonly is used when dont want to add the rule after deletion of already present rule this switch help to skip the script after deletion process 
Param($Inputfile, $List, $Rulename, $Action="block",$Profile="public",[Switch] $DeleteOnly)

$Script:args=""
write-host "Num Args: " $PSBoundParameters.Keys.Count
foreach ($key in $PSBoundParameters.keys) {
    $Script:args+= "`$$key=" + $PSBoundParameters["$key"] + "  "
}
write-host $Script:args

#### If inputfile and rulename not provided as an argument ########

if ( ($Inputfile -eq $null) -And ($Rulename -eq $null) -And ($List -eq $null) )
{ 
    write-host "INPUTFILE/RULENAME/LIST Parameter NOT Passed" 
    Exit 1
    
}

#### This will take current directory path which is used in preparing log file ###################

 $scriptDir = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

 $Show_All_Rulename = netsh advfirewall firewall show rule name=all | select-string -Pattern  'Rule Name'

#### This will show the rulename list to the user whiach is similar in pattern provided by the user #############
if($List -ne $null)
{
$Count = 0
$Show_All_Rulename |  foreach-object {$q=$_.Line -replace 'Rule Name:'
       $Name =  $q -replace '^\s*'
            if($Name -like "$List*")
             { 
             netsh advfirewall firewall show rule name =$Name | select-string -Pattern 'Rule Name' 
             if(-not $?){"RULENAME are not listed..."}
             $Count ++  
             }
            
}
If ($Count -eq 0){Write-host "RuleName Specified by user is not present in firewall"}
 Exit 0
}

# Delete RuleName from firewall rule ................................#

if($Rulename -ne $null)
{
$Count = 0
$Show_All_Rulename  | foreach-object {$q=$_.Line -replace 'Rule Name:'
        $Name =  $q -replace '^\s*'
            if($Name -like "$Rulename")
             {
             $Count ++
             netsh advfirewall firewall delete rule name="$Name"
               if(-not $?){"$Name is not deleted from the firewall rule" >> $scriptDir\Rules_Not_Deleted.txt}
             }
             }
 If ($Count -eq 0){Write-host "RuleName Specified by user is not present in firewall"}
 
}

if ($DeleteOnly) { Exit 0} 
 
# Take Inputfile as an argument from command and add the rule in firewall....................#
if($Inputfile -ne $null)
{
$regex = '^[0-9a-f]{1,4}[\.\:]'
$File  = Get-Content $Inputfile  -ErrorAction Stop | Select-String -Pattern  "$regex"	
 
 # Take file base name which is used in rulename......................#
 $File_Basename = Get-Item $Inputfile -ErrorAction Stop 
 $FileName = $File_Basename.BaseName

$File  | foreach-object {
        $LineNumber = $_.LineNumber
        $Line = $_.Line
        $Ipaddress= $Line.replace(' ','')
        $Ipaddress
# Add inbound rule in firewall ................#
$RuleIn = "$FileName-IN-$LineNumber"
$RuleOut = "$FileName-OUT-$LineNumber"
      netsh advfirewall firewall add rule name=$RuleIn protocol=any dir=in profile=$Profile action=$Action remoteip=$Ipaddress
        if(-not $?){ "$Ipaddress is not added in Inbound firewall rule please provide proper IP Format" >> $scriptDir\IPaddresses_Not_AddedInFirewall.txt  }

# For monitoringand logging purpose txt file is created .......#
        "$RuleIn" >> $scriptDir\RuleName_created_By_Script.txt

# Add outbound rule in firewall ...............#

         netsh advfirewall firewall add rule name=$RuleOut protocol=any dir=out profile=$Profile action=$Action remoteip=$Ipaddress
     if(-not $?){ "$Ipaddress is not added in Outbound firewall rule please provide proper IP Format" >> $scriptDir\IPaddresses_Not_AddedInFirewall.txt }

# For monitoring and logging purpose txt file is created ............#
        "$RuleOut" >>  $scriptDir\RuleName_created_By_Script.txt

}
}




  
			







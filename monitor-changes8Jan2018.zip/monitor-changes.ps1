﻿# $scriptDir Take path of script, which is used for logging  #
$scriptDir = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# RuleName_created_By_Script.txt contain RuleName created by Blocking Script # 
$File = Get-Content $scriptDir\RuleName_created_By_Script.txt

#  If Rulename file which is created by blocking script is empty #
If ($File -eq $Null) {
               "File is blank,File dont have any RuleName"
               Exit 1
                }

netsh advfirewall firewall show rule name=all | select-string -Pattern 'RULE NAME' | foreach-object {$q=$_.Line -replace 'Rule Name:'
        $Name =  $q -replace '^\s*'
# Compare Rulename from Firewall and Rulename Textfile which is created in blocking Script #
 if(Compare-Object $File $Name -IncludeEqual -ExcludeDifferent) 
   { "$Name" >> $scriptDir\RuleNameLog.txt } 
   }

# Log the Deleted Rulename from firewall #
$File2 = Get-Content $scriptDir\RuleNameLog.txt
 foreach ($line in $File)
{
     if (-not($File2 -match $line))
        {
         $Date = $(Get-Date -format 'r') 
         "$line RuleName Deleted from Firewall || $Date " >> $scriptDir\Rulename_deleted_from_firewall.txt
        }
}
  
Start-Sleep -s 10
write-host $Date
Invoke-Expression $scriptDir\monitor-changes.ps1

